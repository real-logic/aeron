/**
 * @file hdr_histogram_version.h
 * @brief Definitions for HdrHistogram's version number.
 */

#ifndef HDR_HISTOGRAM_VERSION_H
#define HDR_HISTOGRAM_VERSION_H

#define HDR_HISTOGRAM_VERSION "0.11.7"

#endif  // HDR_HISTOGRAM_VERSION_H