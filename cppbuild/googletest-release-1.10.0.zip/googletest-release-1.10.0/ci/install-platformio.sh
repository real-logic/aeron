# install PlatformIO
sudo pip install -U platformio

# update PlatformIO
platformio update
